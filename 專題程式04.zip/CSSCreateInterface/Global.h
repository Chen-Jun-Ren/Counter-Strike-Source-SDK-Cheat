#pragma once
#include "include.h"
#include "VMTHook.h"

namespace HOOK // Global Hooks
{
	extern VMTHook* D3D9;
}

namespace Offset
{
	extern uintptr_t d3d9Device;
	extern BYTE oldCode[5];
}

namespace win
{
	extern HWND Window;
	extern WNDPROC oldWNDPROC;
	extern RECT m_Rect;
	extern int windowHeight;
	extern int windowWidth;
}

namespace Controller
{
	extern bool HookTesting;//���Ī��A

	 
	extern bool windowVisible;//���f�i��
	extern bool TargetLine;
	extern bool BonesESP;
	
	
}

namespace ModuleHandle
{
	extern uintptr_t __dwordEngine; //engine.dll�y�`
	extern uintptr_t __dwordClient; //client.dll�y�`
}
