#include"Global.h"

VMTHook* HOOK::D3D9;



uintptr_t Offset::d3d9Device;
BYTE Offset::oldCode[5];



HWND win::Window;
WNDPROC win::oldWNDPROC;
RECT win::m_Rect;
int  win::windowHeight;
int  win::windowWidth;

bool Controller::HookTesting;

bool Controller::windowVisible = false; //�w�]��false
bool Controller::TargetLine = false;
bool Controller::BonesESP = false;





uintptr_t ModuleHandle::__dwordClient;
uintptr_t ModuleHandle::__dwordEngine;