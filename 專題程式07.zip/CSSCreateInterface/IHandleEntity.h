#pragma once
class IHandleEntity
{
public:
	virtual ~IHandleEntity() {}
};