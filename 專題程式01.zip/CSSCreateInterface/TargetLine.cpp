#include "TargetLine.h"
#include "Global.h"
#include "CreateInterface.h"
#include "CBaseEntity.h"
#include "ImGui/imgui.h"
#include "ImGui/imgui_impl_dx9.h"
#include "ImGui/imgui_impl_win32.h"
#include "Tools.h"
void TargetLineESP(IDirect3DDevice9* pDevice)
{
	if (Controller::TargetLine)
	{
		Vec2 Targetpoint;

		Tools::DrawString(win::windowWidth / 2, win::windowHeight / 2, 230, 0, 230, "�����n���@���m�W����");

		for (int i = 0; i <= 32/*Interface->ClientEntityList->GetMaxEntities()*/; i++)
		{
			C_BaseEntity* BaseEntity = (C_BaseEntity*)Interface->ClientEntityList->GetClientEntity(i);
			if (BaseEntity && BaseEntity != Interface->ClientEntityList->GetClientEntity(1) && BaseEntity->GetlifeState() && !BaseEntity->isDormant())
			{
				if (Tools::WorldToScreen(BaseEntity->GetPos(), Targetpoint, pViewMatrix.Matrix, win::windowWidth, win::windowHeight))
				{
					Tools::DrawLine(win::windowWidth / 2, win::windowHeight / 2, Targetpoint.x, Targetpoint.y, 3, 0, pDevice, 255, 0, 255);
				}
				
			}
		}
	}
}