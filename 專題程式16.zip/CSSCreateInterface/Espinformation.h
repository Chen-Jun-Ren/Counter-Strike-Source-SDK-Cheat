#pragma once
#include"include.h"

extern void doInformation(IDirect3DDevice9* pDevice);