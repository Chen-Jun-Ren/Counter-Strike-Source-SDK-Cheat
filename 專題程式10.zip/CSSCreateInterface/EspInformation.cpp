#include"Espinformation.h"
#include "Global.h"
#include "CreateInterface.h"
#include "CBaseEntity.h"
#include "ImGui/imgui.h"
#include "ImGui/imgui_impl_dx9.h"
#include "ImGui/imgui_impl_win32.h"
#include "Tools.h"
#include <math.h>

void DrawNawe(Vec2 projectTOscreen, ImVec4 Setcolor);

void doInformation(IDirect3DDevice9* pDevice)
{
	if (Controller::EspPlayerInfo)
	{
		C_BaseEntity* LocalPlayer = (C_BaseEntity*)Interface->ClientEntityList->GetClientEntity(1);
		for (int i = 0; i <= Interface->ClientEntityList->GetMaxEntities(); i++)
		{
			C_BaseEntity* BaseEntity = (C_BaseEntity*)Interface->ClientEntityList->GetClientEntity(i);
			if (BaseEntity == nullptr || BaseEntity == LocalPlayer || !BaseEntity->GetlifeState() || BaseEntity->isDormant() || BaseEntity->GetvecOrigin().x == 0.000000 || BaseEntity->GetvecOrigin().y == 0.000000 || BaseEntity->GetvecOrigin().z == 0.000000)
				continue;
			if (BaseEntity->IsWeapon())
			{

			}
			if (BaseEntity->IsPlayer())
			{
				if (BaseEntity->GetTeamNumber() == LocalPlayer->GetTeamNumber())
				{
					Vec2 projectTOscreen;
					Interface->VEngineClient->GetPlayerInfo(i, &Controller::info);
					if (Tools::WorldToScreen(BaseEntity->GetvecOrigin(), projectTOscreen))
					{
						DrawNawe(projectTOscreen,Controller::info_color_Team);
					}
				}
				if (BaseEntity->GetTeamNumber() != LocalPlayer->GetTeamNumber())
				{
					Vec2 projectTOscreen;
					Interface->VEngineClient->GetPlayerInfo(i, &Controller::info);
					if (Tools::WorldToScreen(BaseEntity->GetvecOrigin(), projectTOscreen))
					{
						DrawNawe(projectTOscreen, Controller::info_color_Enemy);
					}
				}
			}
		}
	}
}

void DrawNawe(Vec2 projectTOscreen,ImVec4 Setcolor)
{
	if (Controller::info_Shadow)
	{
		Tools::DrawString(projectTOscreen.x + 1, projectTOscreen.y + 1, 0, 0, 0, "Name:%c%c%c%c%c%c%c%c%c%c", *Controller::info.name, *(Controller::info.name + 1), *(Controller::info.name + 2), *(Controller::info.name + 3), *(Controller::info.name + 4), *(Controller::info.name + 5), *(Controller::info.name + 6), *(Controller::info.name + 7), *(Controller::info.name + 8), *(Controller::info.name + 9));
		Tools::DrawString(projectTOscreen.x - 1, projectTOscreen.y - 1, 0, 0, 0, "Name:%c%c%c%c%c%c%c%c%c%c", *Controller::info.name, *(Controller::info.name + 1), *(Controller::info.name + 2), *(Controller::info.name + 3), *(Controller::info.name + 4), *(Controller::info.name + 5), *(Controller::info.name + 6), *(Controller::info.name + 7), *(Controller::info.name + 8), *(Controller::info.name + 9));
		Tools::DrawString(projectTOscreen.x + 1, projectTOscreen.y - 1, 0, 0, 0, "Name:%c%c%c%c%c%c%c%c%c%c", *Controller::info.name, *(Controller::info.name + 1), *(Controller::info.name + 2), *(Controller::info.name + 3), *(Controller::info.name + 4), *(Controller::info.name + 5), *(Controller::info.name + 6), *(Controller::info.name + 7), *(Controller::info.name + 8), *(Controller::info.name + 9));
		Tools::DrawString(projectTOscreen.x - 1, projectTOscreen.y + 1, 0, 0, 0, "Name:%c%c%c%c%c%c%c%c%c%c", *Controller::info.name, *(Controller::info.name + 1), *(Controller::info.name + 2), *(Controller::info.name + 3), *(Controller::info.name + 4), *(Controller::info.name + 5), *(Controller::info.name + 6), *(Controller::info.name + 7), *(Controller::info.name + 8), *(Controller::info.name + 9));
	}
	Tools::DrawString(projectTOscreen.x, projectTOscreen.y, (int)(Setcolor.x * 255), (int)(Setcolor.y * 255), (int)(Setcolor.z * 255), "Name:%c%c%c%c%c%c%c%c%c%c", *Controller::info.name, *(Controller::info.name + 1), *(Controller::info.name + 2), *(Controller::info.name + 3), *(Controller::info.name + 4), *(Controller::info.name + 5), *(Controller::info.name + 6), *(Controller::info.name + 7), *(Controller::info.name + 8), *(Controller::info.name + 9));
}