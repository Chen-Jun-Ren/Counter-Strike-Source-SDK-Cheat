#include "EspBox.h"
#include "Global.h"
#include "CreateInterface.h"
#include "CBaseEntity.h"
#include "ImGui/imgui.h"
#include "ImGui/imgui_impl_dx9.h"
#include "ImGui/imgui_impl_win32.h"
#include "Tools.h"
#include <math.h>



Vec3 head3DPos;
Vec2 head2DPos;

Vec2 Origin2DPos;


void doEspBox(IDirect3DDevice9* pDevice)
{
	if (Controller::ESPBOX)
	{
		C_BaseEntity* LocalPlayer = (C_BaseEntity*)Interface->ClientEntityList->GetClientEntity(1);
		for (int i = 0; i <= Interface->ClientEntityList->GetMaxEntities(); i++)
		{
			C_BaseEntity* BaseEntity = (C_BaseEntity*)Interface->ClientEntityList->GetClientEntity(i);
			if (BaseEntity == nullptr || BaseEntity == LocalPlayer || !BaseEntity->GetlifeState() || BaseEntity->isDormant() || BaseEntity->GetvecOrigin().x == 0.000000 || BaseEntity->GetvecOrigin().y == 0.000000 || BaseEntity->GetvecOrigin().z == 0.000000)
				continue;
			if (BaseEntity->IsWeapon())
			{
				//���եN�X(����)
				/*{
					for (int j = 0; j <= 2; j++)
					{
						if (Tools::GetBonePosEx(BaseEntity->GetBoneBaseAddress(), j, WeaponBonse3Dpos_1, WeaponBonse2Dpos_1))
						{
							Tools::DrawString(WeaponBonse2Dpos_1.x, WeaponBonse2Dpos_1.y, 255, 255, 255, "Id = %d", j);
						}
					}
				}*/
			}
			if (BaseEntity->IsPlayer())
			{
				if (BaseEntity->GetTeamNumber() == LocalPlayer->GetTeamNumber())
				{
					if (Tools::GetBonePosEx(BaseEntity->GetBoneBaseAddress(), 14, head3DPos, head2DPos))
					{
						if (Tools::WorldToScreen(BaseEntity->GetvecOrigin(), Origin2DPos))
						{
							float tall = sqrtf(powf(head2DPos.x - Origin2DPos.x, 2) + powf(head2DPos.y - Origin2DPos.y, 2));//���I�Z���p�⤽��
							Vec2 tl, tr, bl, br;
							tl.x = head2DPos.x - (tall / 4.2);//���W
							tl.y = head2DPos.y - (tall / 5.25);
							tr.x = head2DPos.x + (tall / 4.2);//�k�W
							tr.y = head2DPos.y - (tall / 5.25);
							bl.x = Origin2DPos.x - (tall / 4.2);//���U
							bl.y = Origin2DPos.y;
							br.x = Origin2DPos.x + (tall / 4.2);//�k�U
							br.y = Origin2DPos.y;
							Tools::DrawLine(tl.x, tl.y, tr.x, tr.y, 2, 0, pDevice, 0, 255, 0);
							Tools::DrawLine(tr.x, tr.y, br.x, br.y, 2, 0, pDevice, 0, 255, 0);
							Tools::DrawLine(br.x, br.y, bl.x, bl.y, 2, 0, pDevice, 0, 255, 0);
							Tools::DrawLine(bl.x, bl.y, tl.x, tl.y, 2, 0, pDevice, 0, 255, 0);
						}
					}
				}

				if (BaseEntity->GetTeamNumber() != LocalPlayer->GetTeamNumber())
				{
					if (Tools::GetBonePosEx(BaseEntity->GetBoneBaseAddress(), 14, head3DPos, head2DPos))
					{
						if (Tools::WorldToScreen(BaseEntity->GetvecOrigin(), Origin2DPos))
						{
							float tall = sqrtf(powf(head2DPos.x - Origin2DPos.x, 2) + powf(head2DPos.y - Origin2DPos.y, 2));//���I�Z���p�⤽��
							Vec2 tl, tr, bl, br;
							tl.x = head2DPos.x - (tall / 4.2);
							tl.y = head2DPos.y - (tall / 5.25);
							tr.x = head2DPos.x + (tall / 4.2);
							tr.y = head2DPos.y - (tall / 5.25);
							bl.x = Origin2DPos.x - (tall / 4.2);
							bl.y = Origin2DPos.y;
							br.x = Origin2DPos.x + (tall / 4.2);
							br.y = Origin2DPos.y;
							Tools::DrawLine(tl.x, tl.y, tr.x, tr.y, 2, 0, pDevice, 255, 0, 0);
							Tools::DrawLine(tr.x, tr.y, br.x, br.y, 2, 0, pDevice, 255, 0, 0);
							Tools::DrawLine(br.x, br.y, bl.x, bl.y, 2, 0, pDevice, 255, 0, 0);
							Tools::DrawLine(bl.x, bl.y, tl.x, tl.y, 2, 0, pDevice, 255, 0, 0);
						}
					}
				}
			}
		}
	}
}

/*
     .6-------5					 blb = 0
    .' |   .' |					 brb = 1
  7---+--4'   |		0 = min		 frb = 2
  |   |   |   |		4 = max		 flb = 3
y |  ,0---+---1					 frt = 4
  |.'     | .'  z				 brt = 5
  3-------2						 blt = 6
	  x						     flt = 7

     blt------brt			blt = back-left-top
   .' |    .' |			brt = back-right-top
 flt---+--frt |			brb = back-right-bottom
  |   |    |  |			blb = back-left-bottom
y |  blb---+--brb			flt = front-left-top
  |.'      | .'  z			frt = front-right-top
flb------frb				frb = front-right-bottom
	  x					flb = front-left-bottom
*/