#pragma once
#include "include.h"

extern void doBonesESP(IDirect3DDevice9* pDevice);
