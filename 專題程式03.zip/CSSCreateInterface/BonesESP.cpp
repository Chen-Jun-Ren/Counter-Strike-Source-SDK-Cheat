#include "BonesESP.h"
#include "Global.h"
#include "ImGui/imgui.h"
#include "ImGui/imgui_impl_dx9.h"
#include "ImGui/imgui_impl_win32.h"
void doBonesESP(IDirect3DDevice9* pDevice)
{
	int Bone_ID_A[] = { 16,29,6,7,2,3,29,29,30,16,17,18,12,14,15,28 };//���f�y��1
	int Bone_ID_B[] = { 9,9,9,6,9,2,28,30,31,15,16,17,9,12,12,12 };//���f�y��2
}