#pragma once
#include "include.h"
#include "psapi.h"
#include "Vector.h"

struct Vec2
{
	float x, y;
};

struct CViewMatrix
{
	float Matrix[16];
};

extern ID3DXFont* g_font;
extern ID3DXLine* m_Line;
extern CViewMatrix pViewMatrix;

namespace Tools
{
	extern uintptr_t FindPattern(std::string moduleName, std::string pattern);
	extern void DrawString(LONG x, LONG y, int R, int G, int B, const char* fmt, ...);
	extern void DrawLine(float x1, float y1, float x2, float y2, float width, bool antialias, IDirect3DDevice9* pDevice, int R, int G, int B);
	extern bool WorldToScreen(Vector pos, Vec2& screen, float matrix[16]);
	extern bool GetBonePosEx(uintptr_t boneBase, int boneID, Vector& bonePos, Vec2& screen);
}