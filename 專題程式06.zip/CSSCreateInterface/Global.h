#pragma once
#include "include.h"
#include "VMTHook.h"
#include "ImGui/imgui.h"

namespace HOOK // Global Hooks
{
	extern VMTHook* D3D9;
}

namespace Offset
{
	extern uintptr_t d3d9Device;
	extern BYTE oldCode[5];
}

namespace win
{
	extern HWND Window;
	extern WNDPROC oldWNDPROC;
	extern RECT m_Rect;
	extern int windowHeight;
	extern int windowWidth;
}

namespace Controller
{
	extern bool HookTesting;//���Ī��A

	 
	extern bool windowVisible;//���f�i��
	extern bool TargetLine;
	extern bool BonesESP;

	extern ImVec4 TargetLine_color_Team;
	extern ImVec4 TargetLine_color_Weapon;
	extern ImVec4 TargetLine_color_Enemy;

	extern bool TargetLine_check_Team;
	extern bool TargetLine_check_Weapon;
	extern bool TargetLine_check_Enemy;

	extern float TargetLine_Thickness;
	
}

namespace ModuleHandle
{
	extern uintptr_t __dwordEngine; //engine.dll�y�`
	extern uintptr_t __dwordClient; //client.dll�y�`
}
