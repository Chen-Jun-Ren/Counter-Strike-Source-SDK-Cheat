#include "TargetLine.h"
#include "Global.h"
#include "CreateInterface.h"
#include "CBaseEntity.h"
#include "ImGui/imgui.h"
#include "ImGui/imgui_impl_dx9.h"
#include "ImGui/imgui_impl_win32.h"
#include "Tools.h"

Vec2 Targetpoint;
void Drawshadow(IDirect3DDevice9* pDevice)//�v�l
{
	Tools::DrawLine(win::windowWidth - 1, win::windowHeight - 1, Targetpoint.x - 1, Targetpoint.y - 1, Controller::TargetLine_Thickness, 0, pDevice, 0, 0, 0);
	Tools::DrawLine(win::windowWidth + 1, win::windowHeight + 1, Targetpoint.x + 1, Targetpoint.y + 1, Controller::TargetLine_Thickness, 0, pDevice, 0, 0, 0);
	Tools::DrawLine(win::windowWidth + 1, win::windowHeight - 1, Targetpoint.x + 1, Targetpoint.y - 1, Controller::TargetLine_Thickness, 0, pDevice, 0, 0, 0);
	Tools::DrawLine(win::windowWidth - 1, win::windowHeight + 1, Targetpoint.x - 1, Targetpoint.y + 1, Controller::TargetLine_Thickness, 0, pDevice, 0, 0, 0);
}

void TargetLineESP(IDirect3DDevice9* pDevice)
{
	if (Controller::TargetLine)
	{
		C_BaseEntity* LocalPlayer = (C_BaseEntity*)Interface->ClientEntityList->GetClientEntity(1);

		for (int i = 0; i <= Interface->ClientEntityList->GetMaxEntities(); i++)
		{
			
			C_BaseEntity* BaseEntity = (C_BaseEntity*)Interface->ClientEntityList->GetClientEntity(i);
			if (BaseEntity == nullptr)
				continue;
			if (BaseEntity == Interface->ClientEntityList->GetClientEntity(1))
				continue;
			if (BaseEntity->isDormant() == true)
				continue;
			if (BaseEntity->GetlifeState() == false)
				continue;
			if (BaseEntity->GetvecOrigin().x == 0.000000 && BaseEntity->GetvecOrigin().y == 0.000000 && BaseEntity->GetvecOrigin().z == 0.000000)
				continue;
			if (BaseEntity->IsWeapon() == true)//------Weapon------//
			{
				if (Tools::WorldToScreen(BaseEntity->GetPos(), Targetpoint, pViewMatrix.Matrix) && Controller::TargetLine_check_Weapon)
				{
					Drawshadow(pDevice);
					Tools::DrawLine(win::windowWidth, win::windowHeight, Targetpoint.x, Targetpoint.y, Controller::TargetLine_Thickness, 0, pDevice, (int)(Controller::TargetLine_color_Weapon.x * 255.0f), (int)(Controller::TargetLine_color_Weapon.y * 255.0f), (int)(Controller::TargetLine_color_Weapon.z * 255.0f));
					//���եN�X
					/*{
						Tools::DrawString(Targetpoint.x + 1, Targetpoint.y - 1, 0, 0, 0, "ID = %d \nPos.x = %f \nPos.y = %f\nPos.z = %f", BaseEntity->GetClientClass()->m_ClassID, BaseEntity->GetvecOrigin().x, BaseEntity->GetvecOrigin().y, BaseEntity->GetvecOrigin().z);
						Tools::DrawString(Targetpoint.x - 1, Targetpoint.y + 1, 0, 0, 0, "ID = %d \nPos.x = %f \nPos.y = %f\nPos.z = %f", BaseEntity->GetClientClass()->m_ClassID, BaseEntity->GetvecOrigin().x, BaseEntity->GetvecOrigin().y, BaseEntity->GetvecOrigin().z);
						Tools::DrawString(Targetpoint.x + 1, Targetpoint.y + 1, 0, 0, 0, "ID = %d \nPos.x = %f \nPos.y = %f\nPos.z = %f", BaseEntity->GetClientClass()->m_ClassID, BaseEntity->GetvecOrigin().x, BaseEntity->GetvecOrigin().y, BaseEntity->GetvecOrigin().z);
						Tools::DrawString(Targetpoint.x - 1, Targetpoint.y - 1, 0, 0, 0, "ID = %d \nPos.x = %f \nPos.y = %f\nPos.z = %f", BaseEntity->GetClientClass()->m_ClassID, BaseEntity->GetvecOrigin().x, BaseEntity->GetvecOrigin().y, BaseEntity->GetvecOrigin().z);
						Tools::DrawString(Targetpoint.x, Targetpoint.y, 255, 0, 255, "ID = %d \nPos.x = %f \nPos.y = %f\nPos.z = %f", BaseEntity->GetClientClass()->m_ClassID, BaseEntity->GetvecOrigin().x, BaseEntity->GetvecOrigin().y, BaseEntity->GetvecOrigin().z);
					}*/
				}
			}
			if (BaseEntity->IsPlayer() == true)//------Players------//
			{
				if (Tools::WorldToScreen(BaseEntity->GetvecOrigin(), Targetpoint, pViewMatrix.Matrix))
				{
					if (BaseEntity->GetTeamNumber() == LocalPlayer->GetTeamNumber() && Controller::TargetLine_check_Team)//Team
					{
						Drawshadow(pDevice);
						Tools::DrawLine(win::windowWidth, win::windowHeight, Targetpoint.x, Targetpoint.y, Controller::TargetLine_Thickness, 0, pDevice, (int)(Controller::TargetLine_color_Team.x * 255.0f), (int)(Controller::TargetLine_color_Team.y * 255.0f), (int)(Controller::TargetLine_color_Team.z * 255.0f));
					}
					if (BaseEntity->GetTeamNumber() != LocalPlayer->GetTeamNumber() && Controller::TargetLine_check_Enemy)//Enemy
					{
						Drawshadow(pDevice);
						Tools::DrawLine(win::windowWidth, win::windowHeight, Targetpoint.x, Targetpoint.y, Controller::TargetLine_Thickness, 0, pDevice, (int)(Controller::TargetLine_color_Enemy.x * 255.0f), (int)(Controller::TargetLine_color_Enemy.y * 255.0f), (int)(Controller::TargetLine_color_Enemy.z * 255.0f));
					}
				}
			}
		}
	}
}