#include "include.h"
#include "Hooks.h"
#include "Tools.h"
#include "ImGui/imgui.h"
#include "ImGui/imgui_impl_dx9.h"
#include "ImGui/imgui_impl_win32.h"
#include "Global.h"
//#include "ESPheader.h"
#include "BonesESP.h"
#include "TargetLine.h"

EndSceneFn oEndScene;

bool bInit;
void __stdcall Hooks::EndScene(IDirect3DDevice9* Device)
{
	if (bInit == false)
	{
		bInit = true;
	}

	if(Controller::windowVisible)
	{
		ImGui_ImplDX9_NewFrame();
		ImGui_ImplWin32_NewFrame();
		ImGui::NewFrame();
		/*Menu rendering here*/

		ImGui::Begin(" Counter-Strike:Source - SDK GameHacking");
		{
			if (ImGui::CollapsingHeader("AIM-Bot"))
			{

			}

			if (ImGui::CollapsingHeader("ESP-Hack"))
			{
				ImGui::Checkbox("TargitLine", &Controller::TargetLine);
				if (Controller::TargetLine)
				{
					ImGui::SliderFloat(u8"TargetLine_Thickness", &Controller::TargetLine_Thickness, 1, 10);
					ImGui::Checkbox("Team", &Controller::TargetLine_check_Team);
					if (Controller::TargetLine_check_Team)
					{
						ImGui::ColorEdit3("Team_color", (float*)&Controller::TargetLine_color_Team);
					}

					ImGui::Checkbox("Weapon", &Controller::TargetLine_check_Weapon);
					if (Controller::TargetLine_check_Weapon)
					{
						ImGui::ColorEdit3("Weapon_color", (float*)&Controller::TargetLine_color_Weapon);
					}

					ImGui::Checkbox("Enemy", &Controller::TargetLine_check_Enemy);
					if (Controller::TargetLine_check_Enemy)
					{
						ImGui::ColorEdit3("Enemy_color", (float*)&Controller::TargetLine_color_Enemy);
					}
				}
				ImGui::Checkbox("BonesESP", &Controller::BonesESP);
			}
			
		}

		ImGui::ShowTestWindow();//���յ��f
					
		/*Menu rendering here*/
		ImGui::End();
		ImGui::EndFrame();
		ImGui::Render();
		ImGui_ImplDX9_RenderDrawData(ImGui::GetDrawData());
	}

	TargetLineESP(Device);//�I�s�ؼнu�����;
	doBonesESP(Device);//�I�s���f���;
	
	
	Tools::DrawString(800 + 1, 10 + 1, 0, 0, 0, "�����n���@���m�W����");
	Tools::DrawString(800 + 1, 10 - 1, 0, 0, 0, "�����n���@���m�W����");
	Tools::DrawString(800 - 1, 10 - 1, 0, 0, 0, "�����n���@���m�W����");
	Tools::DrawString(800 - 1, 10 + 1, 0, 0, 0, "�����n���@���m�W����");
	Tools::DrawString(800, 10, 230, 0, 230, "�����n���@���m�W����");

	return oEndScene(Device);
}