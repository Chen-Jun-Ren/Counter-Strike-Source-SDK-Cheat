#pragma once
#include "include.h"
extern void doEspBox(IDirect3DDevice9* pDevice);