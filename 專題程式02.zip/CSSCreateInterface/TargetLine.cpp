#include "TargetLine.h"
#include "Global.h"
#include "CreateInterface.h"
#include "CBaseEntity.h"
#include "ImGui/imgui.h"
#include "ImGui/imgui_impl_dx9.h"
#include "ImGui/imgui_impl_win32.h"
#include "Tools.h"
void TargetLineESP(IDirect3DDevice9* pDevice)
{
	if (Controller::TargetLine)
	{
		Vec2 Targetpoint;

		Tools::DrawString(win::windowWidth / 2, win::windowHeight / 2, 230, 0, 230, "�����n���@���m�W����");

		for (int i = 0; i <= Interface->ClientEntityList->GetMaxEntities(); i++)
		{
			C_BaseEntity* LocalPlayer = (C_BaseEntity*)Interface->ClientEntityList->GetClientEntity(1);
			C_BaseEntity* BaseEntity = (C_BaseEntity*)Interface->ClientEntityList->GetClientEntity(i);
			if (BaseEntity == nullptr)
				continue;
			if (BaseEntity == Interface->ClientEntityList->GetClientEntity(1))
				continue;
			if (BaseEntity->isDormant() == true)
				continue;
			if (BaseEntity->GetlifeState() == false)
				continue;
			if (BaseEntity->IsWeapon() == true)
			{
				if (Tools::WorldToScreen(BaseEntity->GetvecOrigin(), Targetpoint, pViewMatrix.Matrix, win::windowWidth, win::windowHeight))
					Tools::DrawLine(win::windowWidth, win::windowHeight, Targetpoint.x, Targetpoint.y, 3, 0, pDevice, 0, 255, 0);
			}
			if (BaseEntity->IsPlayer() == true)
			{
				if (Tools::WorldToScreen(BaseEntity->GetvecOrigin(), Targetpoint, pViewMatrix.Matrix, win::windowWidth, win::windowHeight))
				{
					if (BaseEntity->GetTeamNumber() == LocalPlayer->GetTeamNumber())
					{
						Tools::DrawLine(win::windowWidth, win::windowHeight, Targetpoint.x, Targetpoint.y, 3, 0, pDevice, 0, 0, 255);
					}
					if (BaseEntity->GetTeamNumber() != LocalPlayer->GetTeamNumber())
					{
						Tools::DrawLine(win::windowWidth, win::windowHeight, Targetpoint.x, Targetpoint.y, 3, 0, pDevice, 255, 0, 0);
					}
				}
			}
		}
	}
}