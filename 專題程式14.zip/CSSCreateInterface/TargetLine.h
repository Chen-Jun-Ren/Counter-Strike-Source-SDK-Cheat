#pragma once
#include"include.h"

extern void TargetLineESP(IDirect3DDevice9* pDevice);