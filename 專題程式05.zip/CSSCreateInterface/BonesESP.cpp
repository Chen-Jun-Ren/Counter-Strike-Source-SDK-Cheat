#include "TargetLine.h"
#include "Global.h"
#include "CreateInterface.h"
#include "CBaseEntity.h"
#include "ImGui/imgui.h"
#include "ImGui/imgui_impl_dx9.h"
#include "ImGui/imgui_impl_win32.h"
#include "Tools.h"
#include "Vector.h"
void doBonesESP(IDirect3DDevice9* pDevice)
{
	if (Controller::BonesESP)
	{
		/*C_BaseEntity* Player2 = (C_BaseEntity*)Interface->ClientEntityList->GetClientEntity(2);
		uintptr_t Address = Player2->GetBoneBaseAddress();*/
		static const int Bone_ID_A[] = { 16,29,6,7,2,3,29,29,30,16,17,18,12,14,15,28 };//���f�y��1
		static const int Bone_ID_B[] = { 9,9,9,6,9,2,28,30,31,15,16,17,9,12,12,12 };//���f�y��2

		Vec2 Bone2D_Pos_A;
		Vec3 Bone3D_Pos_A;

		Vec2 Bone2D_Pos_B;
		Vec3 Bone3D_Pos_B;

		C_BaseEntity* LocalPlayer = (C_BaseEntity*)Interface->ClientEntityList->GetClientEntity(1);

		for (int j = 0; j <= 40; j++)
		{
			C_BaseEntity* BaseEntity = (C_BaseEntity*)Interface->ClientEntityList->GetClientEntity(j);
			if (BaseEntity == nullptr)
				continue;
			if (BaseEntity == Interface->ClientEntityList->GetClientEntity(1))
				continue;
			if (BaseEntity->GetlifeState() == false)
				continue;
			if (BaseEntity->isDormant() == true)
				continue;
			if (BaseEntity->GetvecOrigin().x == 0.000000 && BaseEntity->GetvecOrigin().y == 0.000000 && BaseEntity->GetvecOrigin().z == 0.000000)
				continue;
			if (BaseEntity->IsPlayer() == true)//------Players------//
			{
				for (int i = 0; i <= (sizeof(Bone_ID_A) / 4) - 1; i++)//sizeof(Bone_ID_A) = 72
				{
					if (BaseEntity->GetTeamNumber() == LocalPlayer->GetTeamNumber())
					{
						if ((Tools::GetBonePosEx(BaseEntity->GetBoneBaseAddress(), Bone_ID_A[i], Bone3D_Pos_A, Bone2D_Pos_A)) && (Tools::GetBonePosEx(BaseEntity->GetBoneBaseAddress(), Bone_ID_B[i], Bone3D_Pos_B, Bone2D_Pos_B)))
						{
							Tools::DrawLine(Bone2D_Pos_A.x, Bone2D_Pos_A.y, Bone2D_Pos_B.x, Bone2D_Pos_B.y, 3, 0, pDevice, 0, 0, 255);
						}
					}
					else
					{
						if (BaseEntity->GetTeamNumber() != LocalPlayer->GetTeamNumber())
						{
							if ((Tools::GetBonePosEx(BaseEntity->GetBoneBaseAddress(), Bone_ID_A[i], Bone3D_Pos_A, Bone2D_Pos_A)) && (Tools::GetBonePosEx(BaseEntity->GetBoneBaseAddress(), Bone_ID_B[i], Bone3D_Pos_B, Bone2D_Pos_B)))
							{
								Tools::DrawLine(Bone2D_Pos_A.x, Bone2D_Pos_A.y, Bone2D_Pos_B.x, Bone2D_Pos_B.y, 3, 0, pDevice, 255, 0, 0);
							}
						}
					}
				}
			}
		}
	}

		
	
}